#!/usr/bin/env bash

# DEFINE THE ENV VARIABLES if NEEDED
#export PATH="$PATH:$JAVA_HOME/bin"

# Process Attach version 1.0.0
java -jar process-attach.jar \
    --javaagent-path "/Users/abey.tom/AppServerAgents/4.0.3/ver4.0.3.0/javaagent.jar" \
    --tools-jar-path "/Library/Java/JavaVirtualMachines/jdk1.7.0_25.jdk/Contents/Home/lib/tools.jar" \
    --controller-host "192.168.57.132" \
    --controller-port "8090" \
    --controller-ssl-enabled false \
    --application-name "AttachApp1" \
    --tier-name "Tier1" \
    --node-name "Node" \
    --includes "java,war" \
    --excludes "idea,machineagent,javaagent" \
    --ignore-case \
    --condition "PCTMEM > 40" \
    --node-name-seq 10 \
    --dry-run \
